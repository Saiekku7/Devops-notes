'''
Authors:
Zammam Qadir
Manikanta Pinna
Ekkuluri Saikumar
Please note: This scripts belong to SSA CoE Team.
'''

import boto3,json
import base64
from pykeepass import PyKeePass

print('This script is for TCS Internal use only')
print('In case of any issues while executing the script, Please contact to ssa.coe@tcs.com')

#Function for password validation.
def password_check(passwd):
    SpecialSym = ['$', '@', '#', '%','!', '&']
    val = True

    if len(passwd) < 10:
        print('length should be at least 10')
        val = False

    if len(passwd) > 20:
        print('length should be not be greater than 20')
        val = False

    if not any(char.isdigit() for char in passwd):
        print('Password should have at least one numeral')
        val = False

    if not any(char.isupper() for char in passwd):
        print('Password should have at least one uppercase letter')
        val = False

    if not any(char.islower() for char in passwd):
        print('Password should have at least one lowercase letter')
        val = False

    if not any(char in SpecialSym for char in passwd):
        print('Password should have at least one of the symbols $@#!&')
        val = False
    if val:
        return val
username = input("Enter Username for RDP connection : ")
while(True):
    passwd = input("Please enter passoword\nYour Password must be atleast 10 Characters long which should contain\n a-z,A-Z and special characters :  ")
    valid = password_check(passwd)
    if(valid):
        break

user_data = '''#!/bin/bash
# Update the package lists
sudo apt-get update -y 
echo -e "{passw}\n{passw}\nY" | sudo adduser {usr}                
# Install Docker
sudo apt-get install docker.io -y
sudo systemctl enable docker
sudo systemctl start docker
sudo usermod -aG docker $USER
sudo docker search metasploitable
# Pull Metasploitable2able2 Docker image
sudo docker pull tleemcjr/metasploitable2
# Pull Kali Linux Docker image
sudo docker pull kalilinux/kali-rolling
# Create a Docker network
sudo docker network create pentest
# create ubuntu desktop 
sudo apt install ubuntu-desktop --yes
sudo apt install xrdp --yes
sudo ufw allow 3389
'''.format(usr=username, passw=passwd)

#fetching KeePass Password
database_path = 'Passwords.kdbx' #paste your KeePassXC database path here.
AWS_Keepass_password = input('Enter KeePassXc password: ')#keyring.get_password('AWS-KeePass-Cred', 'AWS') #setting the username and service name, here username is 'AWS' Service name ='AWS-keePass-Cred'.
kp = PyKeePass(database_path, password=AWS_Keepass_password )
entry = kp.find_entries(title='AWS Credentials', first=True) #Here goes the DB title created.

# Encode the user data script
encoded_user_data = base64.b64encode(user_data.encode("utf-8")).decode("utf-8")
if entry:
    ec2 = boto3.client('ec2',aws_access_key_id=entry.username,
                            aws_secret_access_key=entry.password,
                            region_name="us-east-1")
    print('Connection successful !')
    #Create VPC
    print("creating VPC")
    vpc = ec2.create_vpc(
        CidrBlock='10.0.0.0/16',
        TagSpecifications=[
            {
                'ResourceType':'vpc',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': 'Metasploitable2_Lab_Vpc'
                    }
                ]
            }
        ]
    )
    vpcId=vpc['Vpc']['VpcId']
    print("Successfully created VPC , VPC ID : "+ vpcId)


    #Enabling DNS Support
    enableDnsSupport = ec2.modify_vpc_attribute(
        EnableDnsSupport={
            'Value': True
        },
        VpcId=vpcId,
    )
    print("Enabled DNS Support")

    #Enabling DNS Hostnames
    enableDnsHostnames = ec2.modify_vpc_attribute(
        EnableDnsHostnames={
            'Value': True
        },
        VpcId=vpcId,
    )
    print("Enabling DNS Hostnames")

    #Creating Subnet
    print("Creating Subnet")
    subnet=ec2.create_subnet(
        TagSpecifications=[
            {
                'ResourceType': 'subnet',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': 'Metasploitable2_Lab_PublicSubnet'
                    },
                ]
            },
        ],
        CidrBlock='10.0.0.0/24',
        VpcId=vpcId,
        AvailabilityZone='us-east-1a',
    )
    subnetId=subnet['Subnet']['SubnetId']
    print("Created Subnet, subnet ID : " +subnetId)

    #creating InternetGateway
    print("Creating InternetGateway")
    internetGateway=ec2.create_internet_gateway(
        TagSpecifications=[
            {
                'ResourceType': 'internet-gateway',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': 'Metasploitable2_Lab_IGW'
                    },
                ]
            },
        ],
    )
    igwId=internetGateway['InternetGateway']['InternetGatewayId']
    print("Created Internet Gateway, Internet Gateway ID : "+ igwId)

    #Attaching InternetGateway
    print("Attaching Internet Gateway with VPC")
    attachIgw=ec2.attach_internet_gateway(
        InternetGatewayId=igwId,
        VpcId=vpcId
    )
    print("Attached Internet Gateway with VPC")

    #creating Routetable
    print("Creating RouteTable")
    routeTable=ec2.create_route_table(
        VpcId=vpcId,
        TagSpecifications=[
            {
                'ResourceType': 'route-table',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': 'Metasploitable2_Lab_RouteTable'
                    },
                ]
            },
        ]
    )
    routeTableID=routeTable['RouteTable']['RouteTableId']
    print("Created Route Table , RouteTable ID : " + routeTableID)

    #Creating Route
    print("Creating Route")
    route= ec2.create_route(
       DestinationCidrBlock='0.0.0.0/0',
        GatewayId=igwId,
        RouteTableId=routeTableID,
    )
    print("Created Route")

    #Associating Route table with Subnet
    print("Associating RouteTable with subnet")
    assRt=ec2.associate_route_table(
        RouteTableId=routeTableID,
        SubnetId=subnetId
    )
    Associate_RT_ID = assRt['AssociationId']
    print("Associated RouteTable with subnet")

    #creating security group
    print("Creating Security group")
    securityGroup=ec2.create_security_group(
        Description='Security group for Metasploitable2 lab',
        GroupName='Metasploitable2_Lab_SecurityGroup',
        VpcId=vpcId,
        TagSpecifications=[
            {
                'ResourceType': 'security-group',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': 'Metasploitable2_Lab_SecurityGroup'
                    },
                ]
            },
        ]
    )
    sgId=securityGroup['GroupId']
    print("created Security Group , Security Group ID : " + sgId)

    #update ingressrules
    print("Creating Inbound rules")
    ips=input("Enter the ip address in comma separated format , ex:127.0.0.0/32,127.0.0.1/32 : ")
    iplist=ips.split(',')
    for ip in iplist:
        addIngressRules=ec2.authorize_security_group_ingress(
            GroupId=sgId,
            IpPermissions=[
                {
                    'FromPort': 22,
                    'IpProtocol': 'tcp',
                    'IpRanges': [
                        {
                            'CidrIp': ip,
                            'Description': 'SSH access',
                        },
                    ],
                    'ToPort': 22,
                },
                {
                    'FromPort': 3389,
                    'IpProtocol': 'tcp',
                    'IpRanges': [
                        {
                            'CidrIp': ip,
                            'Description': 'RDP access',
                        },
                    ],
                    'ToPort': 3389,
                },
            ],
        )
    print("Added Inbound Rules")
    #creating keypair
    print("Creating Keypair")
    kpname=input("Enter a keypair name : ")
    kp=ec2.create_key_pair(
        KeyName=kpname,
        KeyType='rsa',
        TagSpecifications=[
            {
                'ResourceType': 'key-pair',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': kpname
                    },
                ]
            },
        ],
        KeyFormat='pem'
    )
    private_key_file=open(kpname+'.pem',"w")
    private_key_file.write(kp['KeyMaterial'])
    private_key_file.close
    print("Created a key pair named "+ kpname )

    #launch ec2 instance
    print("Launching a ubuntu instance")
    Ec2 = ec2.run_instances(
        BlockDeviceMappings=[
            {
                'DeviceName': '/dev/sda1',
                'Ebs': {
                    'DeleteOnTermination': True,
                    'VolumeSize': 64
                }
            },
        ],
        TagSpecifications=[
            {
                'ResourceType': 'instance',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': 'Metasploitable2_Lab_Instance'
                    },
                ]
            },
        ],
        ImageId='ami-0c7217cdde317cfec',
        InstanceType='c5a.4xlarge',
        KeyName=kpname,
        MaxCount=1,
        MinCount=1,
        UserData=encoded_user_data,
        NetworkInterfaces=[
            {
                'AssociatePublicIpAddress': True,
                'DeviceIndex': 0,
                'Groups': [
                    sgId,
                ],
                'SubnetId': subnetId
            },
        ]
    )
    instanceId=Ec2['Instances'][0]['InstanceId']
    print("Launched Metasploitable2 Lab Instance, Instance ID : "+ instanceId)

    # Creating Json Objects for deletion Resources
    Resources = {
        'InstanceID': instanceId,
        'vpcId' : vpcId,
        'subnetId' : subnetId,
        'IGW_Id' : igwId,
        'RT_ID' : routeTableID,
        'SG_Id' : sgId,
        'Associate_RT_ID' : Associate_RT_ID,
        'Kpname' : kpname,
    }
    with open('Resources.json', 'w') as outputfile:
        json.dump(Resources, outputfile)
else:
    print('Connection Unsuccessful !')
'''
Authors:
Zammam Qadir
Manikanta Pinna
Ekkuluri Saikumar
Please note: This scripts belong to SSA CoE Team.
'''

import boto3 , json , time
from pykeepass import PyKeePass

#fetching KeePass Password
database_path = 'Passwords.kdbx' # paste your KeePassXC database path here.
AWS_Keepass_password = input('Enter KeePassXc password: ')
kp = PyKeePass(database_path, password=AWS_Keepass_password )
entry = kp.find_entries(title='AWS Credentials', first=True) #Here goes the DB title created.

if entry:
    with open('Resources.json','r') as openfile:
        ob = json.load(openfile)

    client = boto3.client('ec2', region_name='us-east-1',aws_access_key_id=entry.username,
                          aws_secret_access_key=entry.password)
    print('Connection Successful !')

    # To Terminate Instance
    Delete_instance = client.terminate_instances(
        InstanceIds=[
            ob['InstanceID'],
        ],
    )
    print('Instance Is Terminated !')
    time.sleep(35)

    # To detach Internet Gateway
    Detach_IGW= client.detach_internet_gateway(
        InternetGatewayId = ob['IGW_Id'],
        VpcId = ob['vpcId'],
    )
    print('Internet gateway Has Been Detached !')
    time.sleep(1)

    # To delete Internet Gateway
    Delete_IGW = client.delete_internet_gateway(
        InternetGatewayId = ob['IGW_Id']
    )
    print('Internet Gateway Has Been Deleted !')
    time.sleep(3)
    # Disassociate_route_table
    response = client.disassociate_route_table(
        AssociationId=ob['Associate_RT_ID'],
    )
    # to Delete Route Table
    time.sleep(3)
    Delete_RT = client.delete_route_table(
        RouteTableId = ob['RT_ID']
    )
    print('Route Table Has Been Deleted !')
    # To Delete Security Groups
    time.sleep(3)
    Delete_SG = client.delete_security_group(
        GroupId = ob['SG_Id'],
    )
    print('Security group Has Been Deleted !')
    # To Delete Subnet
    time.sleep(3)
    Delete_subnet = client.delete_subnet(
        SubnetId = ob['subnetId'],
    )
    print('Subnet Has Been Deleted !')
    # To Delete VPC
    time.sleep(2)
    Delete_VPC = client.delete_vpc(
        VpcId = ob['vpcId'],
    )
    print('VPC Has Been Deleted !')
    # To Delete KeyPair
    Delete_KP = client.delete_key_pair(
        KeyName = ob['Kpname'],
    )
    print('Keypair Has Been Deleted !')
    print('All Resources have Been Deleted !')
else:
    print('Connection Unsuccessful !')
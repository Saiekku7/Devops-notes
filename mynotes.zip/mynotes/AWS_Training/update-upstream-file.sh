#!/bin/bash

# Fetch current node IPs (example for Kubernetes)
NODE_IPS=$(/home/ec2-user/bin/kubectl get nodes -o jsonpath='{.items[*].status.addresses[?(@.type=="ExternalIP")].address}')

# Debug: Print fetched node IPs
echo "Fetched Node IPs: $NODE_IPS"

# Check if NODE_IPS is empty
if [ -z "$NODE_IPS" ]; then
    echo "No node IPs found. Exiting."
    exit 1
fi

# Build the upstream block
UPSTREAM_CONFIG="upstream cluster_services {\n"
for ip in $NODE_IPS; do
    UPSTREAM_CONFIG+="    server $ip:30001; \n"
done
UPSTREAM_CONFIG+="}\n"

# Debug: Print the upstream config
echo -e "Upstream Config: $UPSTREAM_CONFIG"

# Write new upstream config to the separate file (requires sudo)
echo -e "$UPSTREAM_CONFIG" | sudo tee /etc/nginx/my_upstream.conf > /dev/null

# Reload NGINX (requires sudo)
sudo nginx -s reload


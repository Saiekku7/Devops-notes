#!/bin/bash

# Variables
REGION="eu-north-1"  # Change to your desired region
VPC_CIDR="10.0.0.0/16"
PUBLIC_SUBNET_CIDR="10.0.1.0/24"
PRIVATE_SUBNET_CIDR_1="10.0.2.0/24"
PRIVATE_SUBNET_CIDR_2="10.0.3.0/24"
KEY_NAME="beh-key-pair"
INSTANCE_TYPE="t3.medium"
AMI_ID="ami-0129bfde49ddb0ed6"  # Amazon Linux 2 AMI (change as needed)
EKS_CLUSTER_NAME="beh-eks-cluster"
NODE_GROUP_NAME="beh-node-group"
NODE_INSTANCE_TYPE="t3.medium"
STATIC_IP_NAME="behvm-static-ip"

# Create Key Pair
aws ec2 create-key-pair --key-name "$KEY_NAME" --query 'KeyMaterial' --output text > "${KEY_NAME}.pem" 2>/dev/null
chmod 400 "${KEY_NAME}.pem"
echo "Created Key Pair: $KEY_NAME"

# Create VPC
VPC_ID=$(aws ec2 create-vpc --cidr-block $VPC_CIDR --region $REGION --query 'Vpc.VpcId' --output text 2>/dev/null)
aws ec2 create-tags --resources $VPC_ID --tags Key=Name,Value="Beh VPC" > /dev/null
echo "VPC with name & ID is : Beh VPC --$VPC_ID"

# Create Public Subnet
PUBLIC_SUBNET_ID=$(aws ec2 create-subnet --vpc-id $VPC_ID --cidr-block $PUBLIC_SUBNET_CIDR --availability-zone ${REGION}a --query 'Subnet.SubnetId' --output text 2>/dev/null)
aws ec2 create-tags --resources $PUBLIC_SUBNET_ID --tags Key=Name,Value="Beh Public Subnet" > /dev/null
echo "Public Subnet with name & ID is: Beh Public Subnet --$PUBLIC_SUBNET_ID"

# Create Private Subnet 1
PRIVATE_SUBNET_ID_1=$(aws ec2 create-subnet --vpc-id $VPC_ID --cidr-block $PRIVATE_SUBNET_CIDR_1 --availability-zone ${REGION}a --query 'Subnet.SubnetId' --output text 2>/dev/null)
aws ec2 create-tags --resources $PRIVATE_SUBNET_ID_1 --tags Key=Name,Value="Beh Private Subnet-1" > /dev/null
echo "Private Subnet with name & ID is: Beh Private Subnet-1 --$PRIVATE_SUBNET_ID_1"

# Create Private Subnet 2
PRIVATE_SUBNET_ID_2=$(aws ec2 create-subnet --vpc-id $VPC_ID --cidr-block $PRIVATE_SUBNET_CIDR_2 --availability-zone ${REGION}b --query 'Subnet.SubnetId' --output text 2>/dev/null)
aws ec2 create-tags --resources $PRIVATE_SUBNET_ID_2 --tags Key=Name,Value="Beh Private Subnet-2" > /dev/null
echo "Private Subnet with name & ID is: Beh Private Subnet-2 --$PRIVATE_SUBNET_ID_2"

# Create Internet Gateway
IGW_ID=$(aws ec2 create-internet-gateway --query 'InternetGateway.InternetGatewayId' --output text 2>/dev/null)
aws ec2 attach-internet-gateway --vpc-id $VPC_ID --internet-gateway-id $IGW_ID > /dev/null
aws ec2 create-tags --resources $IGW_ID --tags Key=Name,Value="Beh IGW" > /dev/null
echo "Created and attached Beh IGW : $IGW_ID"

# Create Route Table
ROUTE_TABLE_ID=$(aws ec2 create-route-table --vpc-id $VPC_ID --query 'RouteTable.RouteTableId' --output text 2>/dev/null)
aws ec2 create-route --route-table-id $ROUTE_TABLE_ID --destination-cidr-block 0.0.0.0/0 --gateway-id $IGW_ID > /dev/null 2>&1
aws ec2 associate-route-table --subnet-id $PUBLIC_SUBNET_ID --route-table-id $ROUTE_TABLE_ID > /dev/null 2>&1
echo "Created Route Table: $ROUTE_TABLE_ID"

# Allocate Elastic IP for NAT Gateway
NAT_ALLOC_ID=$(aws ec2 allocate-address --domain vpc --query 'AllocationId' --output text 2>/dev/null)
aws ec2 create-tags --resources $NAT_ALLOC_ID --tags Key=Name,Value="Beh NAT Elastic IP" > /dev/null
echo "Allocated Elastic IP for NAT Gateway: $NAT_ALLOC_ID"

# Create NAT Gateway in the Public Subnet
NAT_GATEWAY_ID=$(aws ec2 create-nat-gateway --subnet-id $PUBLIC_SUBNET_ID --allocation-id $NAT_ALLOC_ID --query 'NatGateway.NatGatewayId' --output text 2>/dev/null)
aws ec2 create-tags --resources $NAT_GATEWAY_ID --tags Key=Name,Value="Beh NAT Gateway" > /dev/null
echo "Created NAT Gateway: $NAT_GATEWAY_ID"

# Create Route Table for Private Subnets
PRIVATE_ROUTE_TABLE_ID=$(aws ec2 create-route-table --vpc-id $VPC_ID --query 'RouteTable.RouteTableId' --output text 2>/dev/null)
aws ec2 create-route --route-table-id $PRIVATE_ROUTE_TABLE_ID --destination-cidr-block 0.0.0.0/0 --nat-gateway-id $NAT_GATEWAY_ID > /dev/null 2>&1

# Associate the Route Table with Private Subnets
aws ec2 associate-route-table --subnet-id $PRIVATE_SUBNET_ID_1 --route-table-id $PRIVATE_ROUTE_TABLE_ID > /dev/null 2>&1
aws ec2 associate-route-table --subnet-id $PRIVATE_SUBNET_ID_2 --route-table-id $PRIVATE_ROUTE_TABLE_ID > /dev/null 2>&1
echo "Created and associated Route Table for Private Subnets: $PRIVATE_ROUTE_TABLE_ID"

# Allocate Elastic IP
ALLOC_ID=$(aws ec2 allocate-address --domain vpc --query 'AllocationId' --output text 2>/dev/null)
aws ec2 create-tags --resources $ALLOC_ID --tags Key=Name,Value="$STATIC_IP_NAME" > /dev/null
echo "Allocated Elastic IP: $ALLOC_ID with name: $STATIC_IP_NAME"

# Create EC2 Instance in Public Subnet
USER_DATA=$(cat <<- EOF
#!/bin/bash
# Update the package repository
yum update -y
# Install Nginx
yum install -y nginx
# Start Nginx service
systemctl start nginx
# Enable Nginx to start on boot
systemctl enable nginx
EOF
)

INSTANCE_ID=$(aws ec2 run-instances --image-id $AMI_ID --count 1 --instance-type $INSTANCE_TYPE --key-name $KEY_NAME --subnet-id $PUBLIC_SUBNET_ID --associate-public-ip-address --user-data "$USER_DATA" --query 'Instances[0].InstanceId' --output text 2>/dev/null)
echo "Created EC2 Instance Beh VM : $INSTANCE_ID"
# Wait for the EC2 instance to be in the running state
aws ec2 wait instance-running --instance-ids $INSTANCE_ID > /dev/null 2>&1
echo "Beh VM Instance with $INSTANCE_ID is now running."

# Associate Elastic IP with EC2 Instance
aws ec2 associate-address --instance-id $INSTANCE_ID --allocation-id $ALLOC_ID > /dev/null 2>&1
echo "Associated Elastic IP with EC2 Instance"

# Create EKS Cluster
eksctl create cluster \
  --name $EKS_CLUSTER_NAME \
  --region $REGION \
  --vpc-private-subnets $PRIVATE_SUBNET_ID_1,$PRIVATE_SUBNET_ID_2 \
  --node-type $NODE_INSTANCE_TYPE --nodes-min 1 --nodes-max 2


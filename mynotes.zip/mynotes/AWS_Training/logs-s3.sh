#!/bin/bash

# Variables
S3_BUCKET="behdemo-applogs-s3"
NAMESPACE="behns" # Change to your namespace
TIME_THRESHOLD=$((3 * 60)) # 30 minutes in seconds

# Get the current time in seconds since epoch
CURRENT_TIME=$(date +%s)

# Get all pods in the specified namespace
pods=$(/home/ec2-user/bin/kubectl get pods -n $NAMESPACE -o jsonpath='{.items[*].metadata.name}')

for pod in $pods; do
    # Get the latest log timestamp
    latest_log_time=$(/home/ec2-user/bin/kubectl logs $pod -n $NAMESPACE --tail=1 --timestamps | awk '{print $1}' | xargs -I {} date -d {} +%s)

    # Check if the latest log is older than 30 minutes
    if [ $((CURRENT_TIME - latest_log_time)) -gt $TIME_THRESHOLD ]; then
        # Get all logs of the pod
        logs=$(/home/ec2-user/bin/kubectl logs $pod -n $NAMESPACE)

        # Create a log file with pod name and current date/time
        timestamp=$(date +%Y%m%d%H%M%S)
        log_file="/tmp/${pod}_logs_${timestamp}.log"
        echo "$logs" > "$log_file"

        zip_file="/tmp/${pod}_logs_${timestamp}.zip"
        zip "$zip_file" "$log_file"
    
        # Upload logs to S3
        aws s3 cp "$zip_file" "s3://$S3_BUCKET/behn-logs/"

        # Extract the Context from the pod name
        context=$(echo $pod | sed 's/.*deployment-\([^ -]*\).*/\1/')

        # Construct the deployment name based on the Context
        deployment_name="app-deployment-${context}"
        service_name="user-service-${context}"
        ingress_name="user-ingress-${context}"
	echo $deployment_name
	echo $service_name
        # Check if the deployment exists before attempting to delete it
        if /home/ec2-user/bin/kubectl get deployment $deployment_name -n $NAMESPACE > /dev/null 2>&1; then
            # Delete the deployment of the pod
            /home/ec2-user/bin/kubectl delete deployment $deployment_name -n $NAMESPACE
            /home/ec2-user/bin/kubectl delete service $service_name -n $NAMESPACE
            /home/ec2-user/bin/kubectl delete ingress $ingress_name -n $NAMESPACE
            
        else
            echo "No deployment found for pod $pod. Skipping deletion."
        fi

        # Clean up the log file
        rm "$log_file"
        rm "$zip_file"
    fi
done

# Now handle Nginx access and error logs from the EC2 instance
timestamp=$(date +%Y%m%d%H%M%S)
nginx_access_log="/var/log/nginx/access.log"
nginx_error_log="/var/log/nginx/error.log"

# Check if the Nginx access and error logs exist
if [ -f "$nginx_access_log" ] && [ -f "$nginx_error_log" ]; then
    # Create log files for Nginx logs
    nginx_access_log_file="/nginx_access_${timestamp}.log"
    nginx_error_log_file="/nginx_error_${timestamp}.log"

    # Copy the logs to temporary files
    cp "$nginx_access_log" "$nginx_access_log_file"
    cp "$nginx_error_log" "$nginx_error_log_file"

    # Zip Nginx logs
    nginx_zip_file="/nginx_logs_${timestamp}.zip"
    zip "$nginx_zip_file" "$nginx_access_log_file" "$nginx_error_log_file"

    # Upload Nginx logs to S3
    aws s3 cp "$nginx_zip_file" "s3://$S3_BUCKET/nginx-logs/"

    # Clean up Nginx log files
    rm "$nginx_access_log_file"
    rm "$nginx_error_log_file"
    rm "$nginx_zip_file"
else
    echo "Nginx logs not found at $nginx_access_log or $nginx_error_log."
fi


AKIA5K4R3LE7PJCWYU5T qB6cBGFyGjUlmPCCtemp1IBpuk24HwmcHuoOcu1f

Step 3: Install AWS CLI v2
``` shell
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
sudo apt install unzip
unzip awscliv2.zip
sudo ./aws/install -i /usr/local/aws-cli -b /usr/local/bin --update
aws configure
```

### Step 4: Install Docker
``` shell
sudo apt-get update
sudo apt install docker.io
docker ps
sudo chown $USER /var/run/docker.sock
```

### Step 5: Install kubectl
``` shell
curl -o kubectl https://amazon-eks.s3.us-west-2.amazonaws.com/1.19.6/2021-01-05/bin/linux/amd64/kubectl
chmod +x ./kubectl
sudo mv ./kubectl /usr/local/bin
kubectl version --short --client
```

### Step 6: Install eksctl
``` shell
curl --silent --location "https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | tar xz -C /tmp
sudo mv /tmp/eksctl /usr/local/bin
eksctl version

#openssl 
openssl genrsa -out ca.key 4096

openssl req -x509 -new -nodes -sha512 -days 3650 \
 -subj "/C=IN/ST=/L=/O=/OU=/CN=my bastion cert" \
 -key ca.key \
 -out ca.crt

openssl genrsa -out ip-192-0-130-51.us-west-2.compute.internal.key 4096

openssl req -sha512 -new \
    -subj "/C=IN/ST=/L=/O=/OU=/CN=ip-192-0-130-51.us-west-2.compute.internal" \
    -key ip-192-0-130-51.us-west-2.compute.internal.key \
    -out ip-192-0-130-51.us-west-2.compute.internal.csr

cat > v3.ext <<-EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
DNS.1=ip-192-0-130-51.us-west-2.compute.internal
DNS.2=192.0.133.150
DNS.3=192.0.130.51
EOF

openssl x509 -req -sha512 -days 3650 \
    -extfile v3.ext \
    -CA ca.crt -CAkey ca.key -CAcreateserial \
    -in ip-192-0-130-51.us-west-2.compute.internal.csr \
    -out ip-192-0-130-51.us-west-2.compute.internal.crt

***************************************



# for Harbor 
cd /
sudo mkdir data/cert
sudo cp ec2-54-245-241-218.us-west-2.compute.amazonaws.com.crt /data/cert/
sudo cp ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key /data/cert/

openssl x509 -inform PEM -in ec2-54-245-241-218.us-west-2.compute.amazonaws.com.crt -out ec2-54-245-241-218.us-west-2.compute.amazonaws.com.cert

sudo cp ec2-54-245-241-218.us-west-2.compute.amazonaws.com.cert /etc/docker/certs.d/ec2-54-245-241-218.us-west-2.compute.amazonaws.com/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.cert
sudo cp ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key /etc/docker/certs.d/ec2-54-245-241-218.us-west-2.compute.amazonaws.com//ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key
sudo cp ca.crt /etc/docker/certs.d/ec2-54-245-241-218.us-west-2.compute.amazonaws.com/ca.crt
ubuntu@ip-172-31-14-112:~/harbor$ ls
LICENSE  ca.srl                                                  ec2-54-245-241-218.us-west-2.compute.amazonaws.com.crt  harbor.yml.tmpl  v3.ext
ca.crt   common.sh                                               ec2-54-245-241-218.us-west-2.compute.amazonaws.com.csr  install.sh
ca.key   ec2-54-245-241-218.us-west-2.compute.amazonaws.com.cert  ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key  prepare
sudo systemctl restart docker

#openssl for docker
cd /etc/docker
sudo mkdir certs.d
cd certs.d
sudo mkdir <domain_name>
cd <domain_name>
sudo nano ca.crt
sudo nano <domain_name>.cert
sudo nano <domain_name>.key

ec2-34-209-161-17.us-west-2.compute.amazonaws.com

 ************************************************
#EKS 

eksctl create cluster --name three-tier-cluster --region us-west-2 --node-type t2.medium --nodes-min 1 --nodes-max 2
aws eks update-kubeconfig --region us-west-2 --name three-tier-cluster
kubectl get nodes
eksctl delete cluster --name three-tier-cluster --region us-west-2


eksctl create cluster \
  --name eks-demo-cluster \
  --region us-west-2 \
  --vpc-private-subnets subnet-0d837d9ea7379207a,subnet-00090e63f525c8a02 \
  --nodegroup-name beh-nodes \
  --node-type t3.medium \
  --nodes 1 \
  --nodes-min 1 \
  --nodes-max 1 \
  --managed \
  --node-private-networking \
  --ssh-access \
  --ssh-public-key spin-test


eksctl create nodegroup \
--cluster eks-demo-cluster \
--name eks-demo-ng \
--node-type t3.medium \
--nodes 1 \
--nodes-min 1 \
--nodes-max 1 \
--region us-west-2 \
--subnet-ids subnet-0d837d9ea7379207a,subnet-00090e63f525c8a02 \
--ssh-access \
--ssh-public-key /home/ubuntu/eks-nodegp.key.pub \
--managed \
--node-private-networking


kubectl create secret docker-registry harbor-registry \
     --docker-server=https://ip-192-0-130-51.us-west-2.compute.internal\
     --docker-username=admin\
     --docker-password=Harbor12345


***************************************

#ARGOCD

kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl delete -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl patch svc argocd-server -n argocd -p '{"spec": {"type": "NodePort"}}'

#PWD
kubectl get secret argocd-initial-admin-secret -o yaml -n argocd  >>admin BmtINwBJpNu11Fzx 6X1COZZsWst1DQdq
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d; 
argocd account update-password


#UI
kubectl edit svc argocd-server -n argocd

kubectl get svc argocd-server -n argocd -o yaml > argocd.yaml 
kubectl apply -f argocd.yaml 
kubectl get svc -n argocd

1.ssh -i beh-dev.pem -L 8080:192.0.139.243:32101 -L 9443:192.0.139.243:31113 ubuntu@ec2-52-13-174-76
2.kubectl port-forward svc/argocd-server -n argocd 30443:443 --address=0.0.0.0 &




# set argo version -- argocd CLI
export ARGO_VERSION="v2.12.13"
# Download the binary
curl -sLO https://github.com/argoproj/argo-workflows/releases/download/${ARGO_VERSION}/argo-linux-amd64.gz

# Unzip
gunzip argo-linux-amd64.gz

# Make binary executable
chmod +x argo-linux-amd64
# Move binary to path
sudo mv ./argo-linux-amd64 /usr/local/bin/argocd

# Test installation
argo version --short
 

******************************

#Jenkins
sudo apt update

sudo apt install openjdk-17-jre -y

java -version
 
curl -fsSL https://pkg.jenkins.io/debian-stable/jenkins.io-2023.key | sudo tee \
  /usr/share/keyrings/jenkins-keyring.asc > /dev/null
echo deb [signed-by=/usr/share/keyrings/jenkins-keyring.asc] \
  https://pkg.jenkins.io/debian-stable binary/ | sudo tee \
  /etc/apt/sources.list.d/jenkins.list > /dev/null

sudo apt-get update

sudo apt-get install jenkins -y

sudo systemctl enable jenkins
sudo systemctl start jenkins
sudo systemctl status jenkins
sudo cat /var/lib/jenkins/secrets/initialAdminPassword copy the Jenkins Admin Password -  ------>a972018c6633430987d0630d0794aff7   saikumar sai@12345 21633f213ab54b91bc4207442773c3fe

--------------------------------
#Troubleshoot Jenkins
sudo update-alternatives --config java --> /usr/lib/jvm/java-17-openjdk-amd64/bin/java
sudo nano /lib/systemd/system/jenkins.service -> port change

# for /jenkins prefix
1.sudo nano /etc/default/jenkins >>port and prefix..
>.....JENKINS_ARGS="--webroot=/var/cache/jenkins/war --prefix=/jenkins --httpPort=$HTTP_PORT --ajp13Port=$AJP_PORT
2.sudo nano /lib/systemd/system/jenkins.service
>>I uncommented Environment="JENKINS_PREFIX=/jenkins"
Then did sudo systemctl daemon-reload  and finally sudo systemctl restart jenkins

#PKIX path building failed troubleshoot for gitlab
$ sudo openssl x509 -in ec2-54-245-241-218.us-west-2.compute.amazonaws.com.crt -text -noout
$ sudo cp /etc/gitlab/ssl/ip-192-0-130-51.us-west-2.compute.internal.crt /etc/gitlab/ssl/ip-192-0-130-51.us-west-2.compute.internal.pem

$ readlink -f $(which java)
$ sudo keytool -importcert -file /etc/gitlab/ssl/ip-192-0-130-51.us-west-2.compute.internal.crt -keystore /usr/lib/jvm/java-17-openjdk-amd64/lib/security/cacerts -alias gitlab-cert #example cmd
# sudo keytool -import -alias your-ca-alias -keystore /usr/lib/jvm/java-17-openjdk-amd64/lib/security/cacerts -file ca.crt 
sudo systemctl restart jenkins

sudo keytool -importcert -file /home/ubuntu/sslcer/ec2-52-13-174-76.us-west-2.compute.amazonaws.com.crt -keystore /usr/lib/jvm/java-17-openjdk-amd64/lib/security/cacerts -alias harbor-cert

***********************************

********************************************

#GITLAB
sudo apt update -y
sudo apt upgrade -y
sudo apt install -y curl openssh-server ca-certificates postfix
curl -sS https://packages.gitlab.com/install/repositories/gitlab/gitlab-ce/script.deb.sh | sudo bash
sudo EXTERNAL_URL="http://ip-192-0-133-150.us-west-2.compute.internal" apt install gitlab-ce
sudo cat /etc/gitlab/initial_root_password --->root Sai@12345 XuT1YE34YqnamfcSpq/d9iBylG874xPgDW7M7zVzosU=
sudo gitlab-ctl status
sudo gitlab-ctl start
sudo gitlab-ctl stop
sudo apt purge postfix -y
sudo apt-get remove gitlab-ce -y
sudo rm -rf /var/opt/gitlab
--kill all process live
sudo pkill -f gitlab
-- Remove paths
sudo rm -rf /opt/gitlab
sudo rm -rf /etc/gitlab
rm -rf /var/opt/gitlab
rm /etc/postfix/main.cf -rf
******************************
$ sudo mkdir -p /etc/gitlab/ssl
$ sudo chmod 755 /etc/gitlab/ssl
sudo openssl genrsa -des3 -out /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key 2048

sudo openssl req -new -key /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key -out /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.csr

sudo cp -v /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.{key,original}
$ sudo openssl rsa -in /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.original -out /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key
$ sudo rm -v /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.original

$ sudo openssl x509 -req -days 1460 -in /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.csr -signkey /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key -out /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.crt

$ sudo rm -v /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.csr

$ sudo chmod 600 /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key
$ sudo chmod 600 /etc/gitlab/ssl/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.crt

$ sudo vi /etc/gitlab/gitlab.rb
----------------------------------------------------------
external_url 'https://ec2-54-245-241-218.us-west-2.compute.amazonaws.com:444'
----------------------------------------------------------
sudo gitlab-ctl reconfigure


**********************************************
#trivy scan
wget https://github.com/aquasecurity/trivy/releases/download/v0.18.3/trivy_0.18.3_Linux-64bit.deb
sudo dpkg -i trivy_0.18.3_Linux-64bit.deb

sudo apt-get update
sudo apt-get install trivy -y

********************************

#Docker SSL Trust
sudo cp ec2-54-245-241-218.us-west-2.compute.amazonaws.com.crt /usr/local/share/ca-certificates/
sudo update-ca-certificates
sudo ls /etc/ssl/certs | grep ec2-54-245-241-218.us-west-2.compute.amazonaws.com

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>..


sudo nano /etc/docker/daemon.json
{
  "insecure-registries" : ["ec2-54-245-241-218.us-west-2.compute.amazonaws.com:8443"]
}

****************************gitjen-proxy*********************************
 
# Default server configuration
#
server {
        listen 80 default_server;
        listen [::]:80 default_server;
        server_name _;

        # Redirect all HTTP requests to HTTPS
        return 301 https://$host$request_uri;
}

server {
        listen 443 ssl default_server;
        listen [::]:443 ssl default_server;

        # SSL configuration
        ssl_certificate /home/ubuntu/sslcerts/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.crt;
        ssl_certificate_key /home/ubuntu/sslcerts/ec2-54-245-241-218.us-west-2.compute.amazonaws.com.key;

        # Note: You should disable gzip for SSL traffic.
        # See: https://bugs.debian.org/773332

        # Read up on ssl_ciphers to ensure a secure configuration.
        # See: https://bugs.debian.org/765782

        root /var/www/html;

        # Add index.php to the list if you are using PHP
        index index.html index.htm index.nginx-debian.html;

        server_name _;

        location / {
           # First attempt to serve request as file, then
           # as directory, then fall back to displaying a 404.
          # try_files $uri $uri/ =404;
           proxy_pass https://192.0.133.150;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
        }

        location /jenkins {
           proxy_pass http://192.0.133.150:8090/jenkins/;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
        }
}


*******************************************************

aws s3api get-object --bucket sai-devsecops-artifact --key springbootdemo-main.zip


docker tag hello-world:latest ec2-52-13-174-76.us-west-2.compute.amazonaws.com/eks_public/eks-demo
docker push ec2-52-13-174-76.us-west-2.compute.amazonaws.com/eks_public/eks-demo



******************************************harbor-proxy****************
# For more information on configuration, see:
#   * Official English Documentation: http://nginx.org/en/docs/
#   * Official Russian Documentation: http://nginx.org/ru/docs/

user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log notice;
pid /run/nginx.pid;

# Load dynamic modules. See /usr/share/doc/nginx/README.dynamic.
include /usr/share/nginx/modules/*.conf;

events {
    worker_connections 1024;
}

http {
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile            on;
    tcp_nopush          on;
    keepalive_timeout   65;
    types_hash_max_size 4096;

    include             /etc/nginx/mime.types;
    default_type        application/octet-stream;
    client_max_body_size 600M;
    # Load modular configuration files from the /etc/nginx/conf.d directory.
    # See http://nginx.org/en/docs/ngx_core_module.html#include
    # for more information.
    include /etc/nginx/conf.d/*.conf;

    server {
        listen       80;
        listen       [::]:80;
        server_name  _;
        root         /usr/share/nginx/html;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;

        error_page 404 /404.html;
        location = /404.html {
        }

        error_page 500 502 503 504 /50x.html;
        location = /50x.html {
        }
    }

# Settings for a TLS enabled server.
#
    server {
        listen       443 ssl;
        listen       [::]:443 ssl;
        http2        on;
        server_name  _;
        root         /usr/share/nginx/html;

        ssl_certificate "/etc/nginx/ssl/server.crt";
        ssl_certificate_key "/etc/nginx/ssl/server.key";
        ssl_session_cache shared:SSL:1m;
        ssl_session_timeout  10m;
        ssl_ciphers PROFILE=SYSTEM;
        ssl_prefer_server_ciphers on;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;
        location / {
            proxy_pass http://ip-192-0-130-51.us-west-2.compute.internal;
        }
        location /jenkins/{
            proxy_pass http://192.0.140.13:8090/jenkins/;
        }
        location /gitlab/{
            proxy_pass https://192.0.139.24/gitlab/;
            proxy_set_header Host $Host;
            proxy_set_header X-Forwarded-For $remote_addr;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_set_header X-Script-Name /gitlab;
        }
        error_page 404 /404.html;
        location = /404.html {
        }

        error_page 500 502 503 504 /50x.html;
        location = /50x.html {
        }
    }
}
*************************************************

    kubectl create secret docker-registry harbor-registry \
     --docker-server=https://ec2-52-13-174-76.us-west-2.compute.amazonaws.com\
     --docker-username=admin\
     --docker-password=Harbor12345


ssh -i "beh-dev.pem" -L localhost:9000:localhost:9000 -L localhost:8084:localhost:8084  -L 8087:localhost:8087 ubuntu@ec2-34-219-255-158.us-west-2.compute.amazonaws.com


docker pull ec2-52-13-174-76.us-west-2.compute.amazonaws.com/eks_public/eks-demo-24:latest

*********************************deploymentFiles***********
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app: spring
  name: spring-demo
spec:
  replicas: 1
  selector:
    matchLabels:
      app: spring
  template:
    metadata:
      labels:
        app: spring
    spec:
      containers:
        - image: >-
            ip-192-0-130-51.us-west-2.compute.internal/eks_public/eks-demo:latest
          name: spring
          ports:
            - containerPort: 8080
      imagePullSecrets:
        - name: harbor-registry
---
apiVersion: v1
kind: Service
metadata:
  labels:
    app: spring
  name: spring-demo
spec:
  ports:
    - nodePort: 30880
      port: 80
      protocol: TCP
      targetPort: 8080
  selector:
    app: spring
  type: NodePort

***************************************



# For more information on configuration, see:
#   * Official English Documentation: http://nginx.org/en/docs/
#   * Official Russian Documentation: http://nginx.org/ru/docs/

user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log notice;
pid /run/nginx.pid;

# Load dynamic modules. See /usr/share/doc/nginx/README.dynamic.
include /usr/share/nginx/modules/*.conf;

events {
    worker_connections 1024;
}

http {
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile            on;
    tcp_nopush          on;
    keepalive_timeout   65;
    types_hash_max_size 4096;

    include             /etc/nginx/mime.types;
    default_type        application/octet-stream;
    client_max_body_size 600M;
    # Load modular configuration files from the /etc/nginx/conf.d directory.
    # See http://nginx.org/en/docs/ngx_core_module.html#include
    # for more information.
    include /etc/nginx/conf.d/*.conf;

    server {
        listen       80;
        listen       [::]:80;
        server_name  _;
        root         /usr/share/nginx/html;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;

        error_page 404 /404.html;
        location = /404.html {
        }

        error_page 500 502 503 504 /50x.html;
        location = /50x.html {
        }
    }

# Settings for a TLS enabled server.
#
    server {
        listen       443 ssl;
        listen       [::]:443 ssl;
        http2        on;
        server_name  _;
        root         /usr/share/nginx/html;

        ssl_certificate "/etc/nginx/ssl/server.crt";
        ssl_certificate_key "/etc/nginx/ssl/server.key";
        ssl_session_cache shared:SSL:1m;
        ssl_session_timeout  10m;
        ssl_ciphers PROFILE=SYSTEM;
        ssl_prefer_server_ciphers on;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;
        location / {
            proxy_pass https://ip-192-0-130-51.us-west-2.compute.internal;
        }
        location /jenkins/{
            proxy_pass http://192.0.140.13:8090/jenkins/;
        }
        location /gitlab/{
            proxy_pass https://192.0.139.24/gitlab/;
            proxy_set_header Host $Host;
            proxy_set_header X-Forwarded-For $remote_addr;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_set_header X-Script-Name /gitlab;
        }
        error_page 404 /404.html;
        location = /404.html {
        }

        error_page 500 502 503 504 /50x.html;
        location = /50x.html {
        }
    }
}



********************************
ssh -i "beh-dev.pem" -L localhost:9000:localhost:9000 -L localhost:8084:localhost:8084  -L 8087:localhost:8087 ubuntu@ec2-35-161-11-206.us-west-2.compute.amazonaws.com


sudo cp harbor.crt /usr/local/share/ca-certificates/
sudo update-ca-certificates
sudo systemctl restart docker
cosign sign --key cosign.key ec2-52-13-174-76.us-west-2.compute.amazonaws.com/eks_public/eks-demo-37

**************************
sg bastion- vm
vm- vm 
spinpriv-nodegroup
harbor-nodegroup
rdp sg -all vms 
 
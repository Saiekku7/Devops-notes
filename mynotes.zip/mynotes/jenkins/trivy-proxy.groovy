import java.net.URLEncoder

pipeline {
    agent any
    tools {
        maven 'maven-3.9.9'
    }
    environment {
        GITLAB_TOKEN_ID = 'gitlab-id'
        GITLAB_REPO_URL = 'https://ec2-54-245-241-218.us-west-2.compute.amazonaws.com/eks/springbootdemo'
        HARBOR_REGISTRY = 'https://ec2-52-13-174-76.us-west-2.compute.amazonaws.com/'
        HARBOR_REPO = 'eks_public/eks-demo'
        HARBOR_CRED_ID = 'harbor-cred'
        MANIFEST_REPO = 'manifestrepo'  // Repository containing manifest files
        MANIFEST_PATH = 'dev'  // Path to manifest files in manifest repository
        BRANCH = 'main'
        GIT_SSL_NO_VERIFY = 'true'
        COSIGN_KEY = 'cosign-key'
        COSIGN_PWD = 'cosign-pwd'
    }

    stages {
        stage('Test Git') {
            steps {
                sh 'git config --global http.sslVerify false'
            }
        }

        stage('Checkout Code') {
            steps {
                script {
                    checkout([$class: 'GitSCM',
                              branches: [[name: "*/${BRANCH}"]],
                              doGenerateSubmoduleConfigurations: false,
                              extensions: [],
                              userRemoteConfigs: [[url:"${GITLAB_REPO_URL}", credentialsId: "${GITLAB_TOKEN_ID}"]]
                    ])
                }
            }
        }

        stage('Maven Build') {
            steps {
                script {
                    dir("${env.WORKSPACE}/") {
                        sh 'mvn clean install'
                    }
                }
            }
        }

        stage('Build Docker Image') {
            steps {
                script {
                    def buildNumber = env.BUILD_NUMBER
                    sh "echo $buildNumber: and ${env.WORKSPACE}"
                    def dockerfilePath = "${env.WORKSPACE}/Dockerfile"
                    def dockerImage = "beh-eks-demo:buidversion-${buildNumber}"
                    sh "echo $dockerImage: "
                    // Build Docker image
                    docker.build(dockerImage, "-f ${dockerfilePath} ${env.WORKSPACE}")
                    sh "echo docker build cmd ok.............."
                }
            }
        }

        stage('Trivy Scan') {
            steps {
                script {
                    def buildNumber = env.BUILD_NUMBER
                    def dockerImage = "beh-eks-demo:buidversion-${buildNumber}"
                    echo "Trivy scanning the docker image: $dockerImage"
                    // sh "trivy image ${dockerImage} --format json > result.txt"
                    sh "trivy image --exit-code 1 --severity CRITICAL --no-progress ${dockerImage} --format json > result2.json"
                    // sh 'mkdir -p /var/lib/jenkins/workspace/Beh-Dev-Job/trivy-report'
                    // sh "trivy image ${dockerImage} > /var/lib/jenkins/workspace/Beh-Dev-Job/trivy-report/result.json "
                }
            }
        }
        
        stage('Cosign & Push Image to Harbor') {
            steps {
                script {
                    def buildNumber = env.BUILD_NUMBER
                    def dockerImage = "beh-eks-demo:buidversion-${buildNumber}"
                    echo "Pushing Docker $dockerImage image to Harbor "        
                    // withCredentials([usernamePassword(credentialsId: 'ecr-demo-credentials', usernameVariable: 'AWS_ACCESS_KEY_ID', passwordVariable: 'AWS_SECRET_ACCESS_KEY')]) {
                    //     // Configure AWS CLI
                    //     sh '''
                    //     aws configure set aws_access_key_id $AWS_ACCESS_KEY_ID
                    //     aws configure set aws_secret_access_key $AWS_SECRET_ACCESS_KEY
                    //     aws configure set default.region us-east-1
                    //     '''
                    //     // Login to ECR
                    //     sh '''
                    //     aws ecr get-login-password --region us-west-2 | docker login --username AWS --password-stdin 916744526142.dkr.ecr.us-west-2.amazonaws.com
                    //     '''
                    //     // Tag Docker image
                    //     sh "docker tag ${dockerImage} 916744526142.dkr.ecr.us-west-2.amazonaws.com/eks-demo:${buildNumber}"
                    //   // Push Docker image to ECR Public
                    //     sh "docker push 916744526142.dkr.ecr.us-west-2.amazonaws.com/eks-demo:${buildNumber}"
                    // }
                    withEnv(["DOCKER_TLS_VERIFY="]){
                    sh 'docker login -u admin -p Harbor12345 ec2-52-13-174-76.us-west-2.compute.amazonaws.com'
                    sh "docker tag ${dockerImage} ec2-52-13-174-76.us-west-2.compute.amazonaws.com/eks_public/eks-demo:${buildNumber}"
                    sh "docker push ec2-52-13-174-76.us-west-2.compute.amazonaws.com/eks_public/eks-demo:${buildNumber}"
                    }
                    withCredentials([
                        file(credentialsId: COSIGN_KEY, variable: 'COSIGN_KEY'),
                        string(credentialsId: COSIGN_PWD, variable: 'COSIGN_PWD')
                    ]) {
                        // Sign the image using Cosign and the password from Jenkins
                        sh """
                            COSIGN_PASSWORD=\$COSIGN_PWD cosign sign --key \$COSIGN_KEY ec2-52-13-174-76.us-west-2.compute.amazonaws.com/eks_public/eks-demo:${buildNumber} -y
                        """
                    }
                }
            }
        }



        stage('Update Manifests') {
            steps {
                script {
                    def buildNumber = env.BUILD_NUMBER
                    def manifestFile = "deployment.yaml"  // Your manifest file to update
                    def manifestFilePath = "${env.WORKSPACE}/${env.MANIFEST_PATH}/${manifestFile}"
                    def newImageTag = "ec2-52-13-174-76.us-west-2.compute.amazonaws.com/eks_public/eks-demo:${buildNumber}"
                    
                    // Checkout manifest repository
                    checkout([$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "${env.GITLAB_TOKEN_ID}", url: "https://ec2-54-245-241-218.us-west-2.compute.amazonaws.com/eks/manifestrepo"]]])

                    // Update build number in the manifest file
                    sh """
                        sed -i 's|image: .*|image: ${newImageTag}|' ${manifestFilePath}
                    """

                    // Commit and push changes
                    dir("${env.MANIFEST_PATH}") {
                        withCredentials([usernamePassword(credentialsId: "${env.GITLAB_TOKEN_ID}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
                            script {
                                def encodedpass = URLEncoder.encode(env.PASSWORD, "UTF-8")
                                def repoUrl = "https://${USERNAME}:${encodedpass}@ec2-54-245-241-218.us-west-2.compute.amazonaws.com/eks/${env.MANIFEST_REPO}"
                                sh """
                                    git config --global user.email 'jenkins@example.com'
                                    git config --global user.name 'jenkins'
                                    git add .
                                    git commit -m 'Updated build number in ${manifestFile}'
                                    git push ${repoUrl} HEAD:main
                                """
                            }
                        }
                    }
                }
            }
        }
    }
}

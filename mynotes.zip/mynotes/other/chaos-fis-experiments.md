# Referrences
https://docs.aws.amazon.com/fis/latest/userguide/fis-actions-reference.html#eks-actions-reference
https://docs.aws.amazon.com/fis/latest/userguide/eks-pod-actions.html#configure-service-account
https://docs.aws.amazon.com/fis/latest/userguide/getting-started-iam-service-role.html#create-fis-role-prereqs
https://docs.aws.amazon.com/eks/latest/userguide/creating-access-entries.html
https://aws.amazon.com/blogs/devops/chaos-engineering-on-amazon-eks-using-aws-fault-injection-simulator/

# 1. Steps For Creating cluster 
eksctl create cluster --name demo-eks --region eu-north-1 --node-type t3.medium --nodes-min 2 --nodes-max 2 --zones eu-north-1a,eu-north-1b
aws eks update-kubeconfig --region eu-central-1 --name demo-eks
kubectl get nodes
aws eks update-kubeconfig --region eu-north-1 --name demo-eks --kubeconfig ~/.kube/config
kubectl config current-context

# delete
eksctl delete cluster --name demo-eks --region eu-north-1
# OIDC (optional)
eksctl utils associate-iam-oidc-provider --cluster demo-cluster --approve --region eu-north-1

# 2. Create a  trust policy and paste the content in it. then create a role and attach the trust policy and attach AWS Managed AWSFaultInjectionSimulatorEKSAccess policy
nano fis-role-trust-policy.json >> my-fis-role trust policy
aws iam create-role --role-name my-fis-role --assume-role-policy-document file://fis-role-trust-policy.json
aws iam attach-role-policy --role-name my-fis-role --policy-arn arn:aws:iam::aws:policy/service-role/AWSFaultInjectionSimulatorEKSAccess


# 3. Create a file named rbac.yaml and add the following.

kind: ServiceAccount
apiVersion: v1
metadata:
  namespace: default
  name: myserviceaccount

---
kind: Role
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  namespace: default
  name: role-experiments
rules:
- apiGroups: [""]
  resources: ["configmaps"]
  verbs: [ "get", "create", "patch", "delete"]
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["create", "list", "get", "delete", "deletecollection"]
- apiGroups: [""]
  resources: ["pods/ephemeralcontainers"]
  verbs: ["update"]
- apiGroups: [""]
  resources: ["pods/exec"]
  verbs: ["create"]
- apiGroups: ["apps"]
  resources: ["deployments"]
  verbs: ["get"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: bind-role-experiments
  namespace: default
subjects:
- kind: ServiceAccount
  name: myserviceaccount
  namespace: default
- apiGroup: rbac.authorization.k8s.io
  kind: User
  name: fis-experiment
roleRef:
  kind: Role
  name: role-experiments
  apiGroup: rbac.authorization.k8s.io


kubectl apply -f rbac.yaml

# 4. For creating access entries in the cluster.
# Option 1: Create access entries.
aws eks create-access-entry \
                 --principal-arn arn:aws:iam::123456789012:role/fis-experiment-role \
                 --username fis-experiment \
                 --cluster-name my-cluster

# Option 2: Add entries to the aws-auth ConfigMap
eksctl create iamidentitymapping \
                 --arn arn:aws:iam::916744526142:role/my-fis-role \
                 --username fis-experiment \
                 --cluster fis-eks

# kubectl -n kube-system edit configmap aws-auth \  # here u have to see ur role like below. (optional)
![alt text](image.png)

# 5. create nginx-deployment.yaml file and add below
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deployment
  labels:
    app: nginx
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:latest
        ports:
        - containerPort: 80
      resources:
          requests:
            cpu: "100m"
            memory: "128Mi"
          limits:
            cpu: "500m"
            memory: "512Mi"
 
---
# nginx-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: nginx-service
spec:
  selector:
    app: nginx
  ports:
    - protocol: TCP
      port: 80
      targetPort: 80
      nodePort: 30001
  type: NodePort

kubectl apply -f dep.yaml





![alt text](image-6.png) --error


# 6. Navigate to AWS FIS and create scenario templates from scenario library by giving appropriate details like the cluster name, namespace, deployment name, IAM role etc. Once done select the experiment and start the experiment.

# 7. Provided sample json template for each experiment 

# pod delete
aws fis create-experiment-template \
    --cli-input-json '{
        "description": "new nginx",
        "targets": {
                "EksPodDeleteTarget": {
                        "resourceType": "aws:eks:pod",
                        "selectionMode": "COUNT(2)",
                        "parameters": {
                                "clusterIdentifier": "arn:aws:eks:eu-north-1:916744526142:cluster/fis-eks",
                                "namespace": "default",
                                "selectorType": "deploymentName",
                                "selectorValue": "nginx-deployment",
                                "targetContainerName": "nginx"
                        }
                }
        },
        "actions": {
                "EksPodDelete": {
                        "actionId": "aws:eks:pod-delete",
                        "parameters": {
                                "kubernetesServiceAccount": "myserviceaccount"
                        },
                        "targets": {
                                "Pods": "EksPodDeleteTarget"
                        }
                }
        },
        "stopConditions": [
                {
                        "source": "none"
                }
        ],
        "roleArn": "arn:aws:iam::916744526142:role/my-fis-role",
        "tags": {},
        "experimentOptions": {
                "accountTargeting": "single-account",
                "emptyTargetResolutionMode": "fail"
        }
}'
![alt text](image-2.png) --pod -delete

# cpu-stress
aws fis create-experiment-template \
    --cli-input-json '{
        "description": "new cpu 1",
        "targets": {
                "EksStressCpuTarget": {
                        "resourceType": "aws:eks:pod",
                        "selectionMode": "COUNT(2)",
                        "parameters": {
                                "availabilityZoneIdentifier": "eu-north-1b",
                                "clusterIdentifier": "arn:aws:eks:eu-north-1:916744526142:cluster/fis-eks",
                                "namespace": "default",
                                "selectorType": "deploymentName",
                                "selectorValue": "nginx-deployment",
                                "targetContainerName": "nginx"
                        }
                }
        },
        "actions": {
                "EksStressCpuAction-02-Cpu": {
                        "actionId": "aws:eks:pod-cpu-stress",
                        "parameters": {
                                "duration": "PT2M",
                                "kubernetesServiceAccount": "myserviceaccount",
                                "percent": "80"
                        },
                        "targets": {
                                "Pods": "EksStressCpuTarget"
                        }
                },
                "EksStressCpuAction-04-Cpu": {
                        "actionId": "aws:eks:pod-cpu-stress",
                        "parameters": {
                                "duration": "PT4M",
                                "kubernetesServiceAccount": "myserviceaccount",
                                "percent": "90"
                        },
                        "targets": {
                                "Pods": "EksStressCpuTarget"
                        },
                        "startAfter": [
                                "EksStressCpuAction-02-Cpu"
                        ]
                },
                "EksStressCpuAction-06-Cpu": {
                        "actionId": "aws:eks:pod-cpu-stress",
                        "parameters": {
                                "duration": "PT6M",
                                "kubernetesServiceAccount": "myserviceaccount",
                                "percent": "100"
                        },
                        "targets": {
                                "Pods": "EksStressCpuTarget"
                        },
                        "startAfter": [
                                "EksStressCpuAction-04-Cpu"
                        ]
                }
        },
        "stopConditions": [
                {
                        "source": "none"
                }
        ],
        "roleArn": "arn:aws:iam::916744526142:role/my-fis-role",
        "tags": {},
        "experimentOptions": {
                "accountTargeting": "single-account",
                "emptyTargetResolutionMode": "fail"
        }
}'
![alt text](image-3.png) --cpu -stress



# network latency
aws fis create-experiment-template \
    --cli-input-json '{
        "description": "Inject increasing network latency on one or more EKS pods, targeting based on cluster and application label",
        "targets": {
                "EksStressNetworkTarget": {
                        "resourceType": "aws:eks:pod",
                        "selectionMode": "ALL",
                        "parameters": {
                                "availabilityZoneIdentifier": "eu-north-1b",
                                "clusterIdentifier": "arn:aws:eks:eu-north-1:916744526142:cluster/fis-eks",
                                "namespace": "default",
                                "selectorType": "deploymentName",
                                "selectorValue": "nginx-deployment",
                                "targetContainerName": "nginx"
                        }
                }
        },
        "actions": {
                "EksStressNetworkAction-010-Latency": {
                        "actionId": "aws:eks:pod-network-latency",
                        "parameters": {
                                "delayMilliseconds": "200",
                                "duration": "PT5M",
                                "kubernetesServiceAccount": "myserviceaccount"
                        },
                        "targets": {
                                "Pods": "EksStressNetworkTarget"
                        }
                }
        },
        "stopConditions": [
                {
                        "source": "none"
                }
        ],
        "roleArn": "arn:aws:iam::916744526142:role/my-fis-role",
        "tags": {
                "Name": "EKS Stress: Network Latency"
        },
        "experimentOptions": {
                "accountTargeting": "single-account",
                "emptyTargetResolutionMode": "fail"
        }
}'

# io stress
aws fis create-experiment-template \
    --cli-input-json '{
        "description": "Inject increasing disk utilization on one or more EKS pods, targeting based on cluster and application label",
        "targets": {
                "EksStressDiskTarget": {
                        "resourceType": "aws:eks:pod",
                        "selectionMode": "ALL",
                        "parameters": {
                                "clusterIdentifier": "arn:aws:eks:eu-north-1:916744526142:cluster/fis-eks",
                                "namespace": "default",
                                "selectorType": "deploymentName",
                                "selectorValue": "nginx-deployment",
                                "targetContainerName": "nginx"
                        }
                }
        },
        "actions": {
                "EksStressDiskAction-01-Disk": {
                        "actionId": "aws:eks:pod-io-stress",
                        "parameters": {
                                "duration": "PT2M",
                                "kubernetesServiceAccount": "myserviceaccount",
                                "percent": "80"
                        },
                        "targets": {
                                "Pods": "EksStressDiskTarget"
                        }
                }
        },
        "stopConditions": [
                {
                        "source": "none"
                }
        ],
        "roleArn": "arn:aws:iam::916744526142:role/my-fis-role",
        "tags": {
                "Name": "EKS Stress: Disk"
        },
        "experimentOptions": {
                "accountTargeting": "single-account",
                "emptyTargetResolutionMode": "fail"
        }
}'
![alt text](image-7.png) --io stress

# mem stress
aws fis create-experiment-template \
    --cli-input-json '{
        "description": "Inject increasing memory load on one or more EKS pods, targeting based on cluster and application label",
        "targets": {
                "EksStressMemoryTarget": {
                        "resourceType": "aws:eks:pod",
                        "selectionMode": "COUNT(2)",
                        "parameters": {
                                "clusterIdentifier": "arn:aws:eks:eu-north-1:916744526142:cluster/fis-eks",
                                "namespace": "default",
                                "selectorType": "deploymentName",
                                "selectorValue": "nginx-deployment",
                                "targetContainerName": "nginx"
                        }
                }
        },
        "actions": {
                "EksStressMemoryAction-02-Memory": {
                        "actionId": "aws:eks:pod-memory-stress",
                        "parameters": {
                                "duration": "PT2M",
                                "kubernetesServiceAccount": "myserviceaccount",
                                "percent": "80"
                        },
                        "targets": {
                                "Pods": "EksStressMemoryTarget"
                        }
                }
        },
        "stopConditions": [
                {
                        "source": "none"
                }
        ],
        "roleArn": "arn:aws:iam::916744526142:role/my-fis-role",
        "tags": {
                "Name": "EKS Stress: Memory"
        },
        "experimentOptions": {
                "accountTargeting": "single-account",
                "emptyTargetResolutionMode": "fail"
        }
}'
![alt text](image-4.png) --mem-stress
![alt text](imagel-5.png)




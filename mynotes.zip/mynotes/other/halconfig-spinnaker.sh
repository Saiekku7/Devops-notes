aws eks update-kubeconfig --region us-west-2 --name eks-demo-cluster --alias eks-test

hal config features edit --chaos true
sudo hal deploy apply
sudo hal deploy connect
sudo apt install mysql-server -y
sudo snap install --classic go
go version


git clone https://github.com/Netflix/chaosmonkey.git
cd chaosmonkey/
go mod tidy
go build -o chaosmonkey ~/chaosmonkey/cmd/chaosmonkey/main.go

#MySQL Config
CREATE DATABASE chaosmonkey;
use chaosmonkey;
CREATE USER 'chaosmonkey'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON chaosmonkey.* TO 'chaosmonkey'@'localhost';
FLUSH PRIVILEGES;

export PATH=$PATH:/usr/local/go/bin
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc

export GOPATH=$HOME/go
echo 'export GOPATH=$HOME/go' >> ~/.bashrc
export GOBIN=$HOME/go/bin
echo 'export GOBIN=$HOME/go/bin' >> ~/.bashrc
export PATH=$PATH:$GOBIN
echo 'export PATH=$PATH:$GOBIN' >> ~/.bashrc

export PATH=$PATH:/home/ubuntu/chaosmonkey
echo 'export PATH=$PATH:/home/ubuntu/chaosmonkey' >> ~/.bashrc

chaosmonkey --version

#AWS 
hal config provider aws account list
hal config provider aws enable
#Create role and attach to Spinnaker ec2
# first create policy chaosmonkeypolicy.json, then from ec2 instance profile create role with ec2full, autoscaling , s3 iam read only permissions
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "autoscaling:TerminateInstanceInAutoScalingGroup",
                "autoscaling:DescribeAutoScalingGroups",
                "autoscaling:DescribeAutoScalingInstances",
                "ec2:DescribeInstances",
                "ec2:TerminateInstances"
            ],
            "Resource": "*"
        }
    ]
}
#SpinnakerChaosRole arn:aws:iam::916744526142:role/SpinnakerChaosRole
hal config provider aws account add my-aws-account --account-id 916744526142 --assume-role arn:aws:iam::916744526142:role/SpinnakerChaosRole
#hal config features edit --chaos true 
hal config chaos edit --enabled true

sudo nano chaosmonkey.toml 
[chaosmonkey]
enabled = true
schedule_enabled = true
leashed = false
accounts = ["my-aws-account"]
[schedule]
start_hour = 9
end_hour = 17
[database]
host = "localhost"
name = "chaosmonkey"
user = "chaosmonkey"
encrypted_password = "chaosmonkey"
[spinnaker]
endpoint = "http://ec2-35-160-8-181.us-west-2.compute.amazonaws.com:8084"
[eks-beh-nodes-fccab2f0-4cc4-0a1b-6794-b5dc15cb49d4]
enabled = true

sudo mkdir -p /etc/chaosmonkey/
sudo cp ~/chaosmonkey/chaosmonkey.toml /etc/chaosmonkey/
sudo mkdir -p /apps/chaosmonkey
sudo ./chaosmonkey install
# [213333] 2025/03/07 08:40:35 Creating /apps/chaosmonkey/chaosmonkey-terminate.sh
# [213333] 2025/03/07 08:40:35 Creating /apps/chaosmonkey/chaosmonkey-schedule.sh
# [213333] 2025/03/07 08:40:35 Creating /etc/cron.d/chaosmonkey-schedule
# [213333] 2025/03/07 08:40:35 chaosmonkey cron is installed successfully
# [213333] 2025/03/07 08:40:35 Successfully applied database migrations. Number of migrations applied:  0
# [213333] 2025/03/07 08:40:35 database migration applied successfully
# [213333] 2025/03/07 08:40:35 installation done!

#bookstore create on spinnaker then do this
sudo ./chaosmonkey config bookstore
sudo ./chaosmonkey fetch-schedule
sudo ./chaosmonkey terminate bookstore my-aws-account --region=us-west-2 --cluster=eks-demo-cluster 
#[223833] 2025/03/07 09:51:50 No eligible instances in group, nothing to terminate: InstanceGroup{app=bookstore account=my-aws-account region=us-west-2 stack= cluster=eks-demo-cluster}


=======================================================================

#Troubleshoot for ChaosMOnkey migration step
sudo nano /etc/mysql/mysql.conf.d/mysqld.cnf
comment this
#bind-address           = 127.0.0.1
#mysqlx-bind-address    = 127.0.0.1
bind-address = 0.0.0.0     # if need 

# CREATE USER 'chaosmonkey'@'35.160.8.181' IDENTIFIED BY 'chaosmonkey';
# GRANT ALL PRIVILEGES ON chaosmonkey.* TO 'chaosmonkey'@'35.160.8.181';
# FLUSH PRIVILEGES;

#Authentication
sudo mysql -u root -p
select user, host, plugin from mysql.user where user='chaosmonkey';
ALTER USER 'chaosmonkey'@'%' IDENTIFIED WITH mysql_native_password BY 'chaosmonkey';
ALTER USER 'chaosmonkey'@'localhost' IDENTIFIED WITH mysql_native_password BY 'chaosmonkey';
flush privileges;

#UTC
SET GLOBAL time_zone = '+00:00';
SET time_zone = '+00:00';

sudo mysql_tzinfo_to_sql /usr/share/zoneinfo | sudo mysql -u root -p mysql   # utc authentication error fix 
SELECT * FROM mysql.time_zone_name LIMIT 10;

# [chaosmonkey]
# enabled = true
# schedule_enabled = true
# leashed = false
# accounts = ["916744526142"]

# [schedule]
# start_hour = 9
# end_hour = 17

# [database]
# host = "35.160.8.181"
# name = "chaosmonkey"
# user = "chaosmonkey"
# encrypted_password = "chaosmonkey"

# [spinnaker]
# endpoint = "http://ec2-35-160-8-181.us-west-2.compute.amazonaws.com:8084"
.........................................................

 
[mysqld]
#
 
# * Basic Settings
#
user            = mysql
# pid-file      = /var/run/mysqld/mysqld.pid
# socket        = /var/run/mysqld/mysqld.sock
port            = 3306
# datadir       = /var/lib/mysql
default-authentication-plugin=mysql_native_password
default-time-zone = 'UTC'
 
# If MySQL is running as a replication slave, this should be
# changed. Ref https://dev.mysql.com/doc/refman/8.0/en/server-system-variables.html#sysvar_tmpdir
# tmpdir                = /tmp
#
# Instead of skip-networking the default is now to listen only on
# localhost which is more compatible and is not less secure.
#bind-address           = 127.0.0.1
#mysqlx-bind-address    = 127.0.0.1
bind-address = 0.0.0.0
#
# * Fine Tuning
#
key_buffer_size         = 16M
# max_allowed_packet    = 64M
# thread_stack          = 256K
 
# thread_cache_size       = -1
 
# This replaces the startup script and checks MyISAM tables if needed
# the first time they are touched
myisam-recover-options  = BACKUP
 
# max_connections        = 151
 
# table_open_cache       = 4000
 
#
# * Logging and Replication
#
# Both location gets rotated by the cronjob.
#
# Log all queries
# Be aware that this log type is a performance killer.
# general_log_file        = /var/log/mysql/query.log
# general_log             = 1
#
# Error log - should be very few entries.
#
log_error = /var/log/mysql/error.log
#
# Here you can see queries with especially long duration
# slow_query_log                = 1
# slow_query_log_file   = /var/log/mysql/mysql-slow.log
# long_query_time = 2
# log-queries-not-using-indexes
#
# The following can be used as easy to replay backup logs or for replication.
# note: if you are setting up a replication slave, see README.Debian about
#       other settings you may need to change.
# server-id             = 1
# log_bin                       = /var/log/mysql/mysql-bin.log
# binlog_expire_logs_seconds    = 2592000
max_binlog_size   = 100M
# binlog_do_db          = include_database_name
# binlog_ignore_db      = include_database_name

==========================================END===================================
sudo ls /home/spinnaker
halyard-2025-03-06_09-15-45-231Z.tar -->>> hal backup 
#EKS-Context

1. aws autoscaling describe-auto-scaling-instances --region us-west-2 --instance-ids i-067bdc1aae8274d8c
# {
#     "AutoScalingInstances": [
#         {
#             "InstanceId": "i-067bdc1aae8274d8c",
#             "InstanceType": "t3.medium",
#             "AutoScalingGroupName": "eks-beh-nodes-fccab2f0-4cc4-0a1b-6794-b5dc15cb49d4",
#             "AvailabilityZone": "us-west-2b",
#             "LifecycleState": "InService",
#             "HealthStatus": "HEALTHY",
#             "LaunchTemplate": {
#                 "LaunchTemplateId": "lt-027eb94c846cf12e7",
#                 "LaunchTemplateName": "eks-fccab2f0-4cc4-0a1b-6794-b5dc15cb49d4",
#                 "Version": "1"
#             },
#             "ProtectedFromScaleIn": false
#         }
#     ]
# }

2.  #2054179555-config directory is not needed but getting this 
sudo ls -l /home/spinnaker/.hal/default/staging/dependencies/
total 4
drw-r----- 2 spinnaker spinnaker 4096 Mar  7 08:06 2054179555-config

sudo rm -rf /home/spinnaker/.hal/default/staging/dependencies/2054179555-config ## remvoing dir and making file 
echo "{}" | sudo tee /home/spinnaker/.hal/default/staging/dependencies/2054179555-config
sudo chmod 644 /home/spinnaker/.hal/default/staging/dependencies/2054179555-config
 
hal config provider kubernetes enable  ## EKS ACCOunts
hal config provider kubernetes account add eks-test --context $CONTEXT --kubeconfig-file "/home/spinnaker/.kube/config"
hal config provider kubernetes account list 
+ Get current deployment
  Success
+ Get the kubernetes provider
  Success
+ Accounts for kubernetes:
  - eks-demo-test
  - demo-test
  - eks-test

hal config provider kubernetes account get eks-test  
kubectl config current-context

hal config provider kubernetes account edit eks-test --context eks-test


apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-test
  labels:
    app: nginx-test
spec:
  replicas: 2
  selector:
    matchLabels:
      app: nginx-test
  template:
    metadata:
      labels:
        app: nginx-test
    spec:
      containers:
      - name: nginx
        image: nginx:latest
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: nginx-test-service
spec:
  type: NodePort
  ports:
  - port: 80
    targetPort: 80
    nodePort: 30080  # Optional: specify a node port if you want to access it directly
  selector:
    app: nginx-test


_______________________________________________

apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app: nginx-test
    app.kubernetes.io/managed-by: spinnaker
    app.kubernetes.io/name: bookstore
  name: nginx-test
spec:
  replicas: 2
  selector:
    matchLabels:
      app: nginx-test
  template:
    metadata:
      labels:
        app: nginx-test
        app.kubernetes.io/managed-by: spinnaker
        app.kubernetes.io/name: bookstore
    spec:
      containers:
        - image: 'nginx:latest'
          name: nginx
          ports:
            - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: nginx-test-service
spec:
  ports:
    - nodePort: 30080
      port: 80
      targetPort: 80
  selector:
    app: nginx-test
  type: NodePort

_______________________________________________


# from dir to text file
ubuntu@ip-192-0-11-254:~/chaosmonkey$ sudo ls -ld /home/spinnaker/.kube/config
drwxr-xr-x 2 root root 4096 Mar  5 10:48 /home/spinnaker/.kube/config
ubuntu@ip-192-0-11-254:~/chaosmonkey$ sudo rm -rf /home/spinnaker/.kube/config
ubuntu@ip-192-0-11-254:~/chaosmonkey$ sudo ls -ld /home/spinnaker/.kube/config ## remvoed the dir
ls: cannot access '/home/spinnaker/.kube/config': No such file or directory
sudo mkdir -p /home/spinnaker/.kube
ubuntu@ip-192-0-11-254:~/chaosmonkey$ sudo cp /home/ubuntu/.kube/config /home/spinnaker/.kube/config
ubuntu@ip-192-0-11-254:~/chaosmonkey$ sudo ls -ld /home/spinnaker/.kube/config
-rw------- 1 root root 4590 Mar  7 10:55 /home/spinnaker/.kube/config
ubuntu@ip-192-0-11-254:~/chaosmonkey$ sudo chown spinnaker:spinnaker /home/spinnaker/.kube/config #permissions
ubuntu@ip-192-0-11-254:~/chaosmonkey$ sudo chmod 600 /home/spinnaker/.kube/config



/opt/spinnaker/config/gate.yaml  ##CORS issue
## WARNING
## This file was autogenerated, and _will_ be overwritten by Halyard.
## Any edits you make here _will_ be lost.

spectator:
  applicationName: ${spring.application.name}
  webEndpoint:
    enabled: false

spinnaker:
  extensibility:
    plugins: {}
    repositories: {}
    plugins-root-path: /opt/gate/plugins
    strict-plugin-loading: false

server:
  ssl:
    enabled: false
  port: '8084'
  address: 0.0.0.0

security:
  basic:
    enabled: true
  user: {}

cors:
  enabled: true
  allowedOrigins: ['*']  # Allow all origins
  allowedMethods: ['*']   # Allow all methods
  allowedHeaders: ['*']    # Allow all headers

google: {}

integrations:
  gremlin:
    enabled: false
    baseUrl: https://api.gremlin.com/v1

# halconfig
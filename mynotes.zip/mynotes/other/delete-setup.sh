#!/bin/bash

# Variables
REGION="eu-north-1"  # Change to your desired region
VPC_CIDR="10.0.0.0/16"
PUBLIC_SUBNET_CIDR="10.0.1.0/24"
PRIVATE_SUBNET_CIDR_1="10.0.2.0/24"
PRIVATE_SUBNET_CIDR_2="10.0.3.0/24"
KEY_NAME="beh-key-pair"
EKS_CLUSTER_NAME="beh-eks-cluster"
NODE_GROUP_NAME="beh-node-group"
STATIC_IP_NAME="behvm-static-ip"

# Get the VPC ID
VPC_ID=$(aws ec2 describe-vpcs --filters "Name=cidr,Values=$VPC_CIDR" --query "Vpcs[0].VpcId" --output text --region $REGION 2>/dev/null)

# Debugging output
if [ -z "$VPC_ID" ]; then
    echo "No VPC found with CIDR $VPC_CIDR."
    exit 1
fi

# Get the Internet Gateway ID
IGW_ID=$(aws ec2 describe-internet-gateways --filters "Name=attachment.vpc-id,Values=$VPC_ID" --query "InternetGateways[0].InternetGatewayId" --output text --region $REGION 2>/dev/null)

# Get the Elastic IP Allocation ID and Public IP
ALLOC_ID=$(aws ec2 describe-addresses --filters "Name=tag:Name,Values=$STATIC_IP_NAME" --query "Addresses[0].AllocationId" --output text --region $REGION 2>/dev/null)
PUBLIC_IP=$(aws ec2 describe-addresses --filters "Name=tag:Name,Values=$STATIC_IP_NAME" --query "Addresses[0].PublicIp" --output text --region $REGION 2>/dev/null)

# Get the EC2 Instance ID
INSTANCE_ID=$(aws ec2 describe-instances --filters "Name=subnet-id,Values=$(aws ec2 describe-subnets --filters "Name=vpc-id,Values=$VPC_ID" --query "Subnets[?CidrBlock=='$PUBLIC_SUBNET_CIDR'].SubnetId" --output text --region $REGION 2>/dev/null)" --query "Reservations[0].Instances[0].InstanceId" --output text --region $REGION 2>/dev/null)

# Debugging output
if [ -z "$INSTANCE_ID" ]; then
    echo "No EC2 instance found in the public subnet."
else
    echo "Found EC2 Instance ID: $INSTANCE_ID"
fi

# Get the EKS Node Group ARN
NODE_GROUP_ARN=$(aws eks list-nodegroups --cluster-name $EKS_CLUSTER_NAME --query "nodegroups[?contains(@, '$NODE_GROUP_NAME')]" --output text --region $REGION 2>/dev/null)

# Terminate EC2 Instance
if [ -n "$INSTANCE_ID" ]; then
    aws ec2 terminate-instances --instance-ids $INSTANCE_ID --region $REGION > /dev/null 2>&1
    echo "Terminated EC2 Instance: $INSTANCE_ID"
    # Wait for the EC2 instance to be terminated
    aws ec2 wait instance-terminated --instance-ids $INSTANCE_ID --region $REGION > /dev/null 2>&1
    echo "EC2 Instance $INSTANCE_ID has been terminated."
fi

# Disassociate Elastic IP
if [ -n "$PUBLIC_IP" ]; then
    # Attempt to disassociate the Elastic IP using the public IP
    DISASSOCIATE_OUTPUT=$(aws ec2 disassociate-address --public-ip $PUBLIC_IP --region $REGION 2>&1)
    if [ $? -eq 0 ]; then
        echo "Disassociated Elastic IP: $PUBLIC_IP"
    else
        echo "Failed to disassociate Elastic IP: $PUBLIC_IP. Error: $DISASSOCIATE_OUTPUT"
    fi
else
    echo "Elastic IP $STATIC_IP_NAME is not associated with any instance."
fi

# Release Elastic IP
if [ -n "$ALLOC_ID" ]; then
    RELEASE_OUTPUT=$(aws ec2 release-address --allocation-id $ALLOC_ID --region $REGION 2>&1)
    if [ $? -eq 0 ]; then
        echo "Released Elastic IP: $ALLOC_ID"
    else
        echo "Failed to release Elastic IP: $ALLOC_ID. Error: $RELEASE_OUTPUT"
    fi
fi

# Delete Internet Gateway
if [ -n "$IGW_ID" ]; then
    # Check if the Internet Gateway is attached
    ATTACHED_VPC_ID=$(aws ec2 describe-internet-gateways --internet-gateway-ids $IGW_ID --query "InternetGateways[0].Attachments[0].VpcId" --output text --region $REGION 2>/dev/null)
    if [ "$ATTACHED_VPC_ID" == "$VPC_ID" ]; then
        aws ec2 detach-internet-gateway --internet-gateway-id $IGW_ID --vpc-id $VPC_ID --region $REGION > /dev/null 2>&1
        echo "Detached Internet Gateway: $IGW_ID"
    else
        echo "Internet Gateway $IGW_ID is not attached to the VPC."
    fi

    # Delete Internet Gateway
    aws ec2 delete-internet-gateway --internet-gateway-id $IGW_ID --region $REGION > /dev/null 2>&1
    echo "Deleted Internet Gateway: $IGW_ID"
fi

# Delete Subnets
for SUBNET_ID in $(aws ec2 describe-subnets --filters "Name=vpc-id,Values=$VPC_ID" --query "Subnets[].SubnetId" --output text --region $REGION); do
    aws ec2 delete-subnet --subnet-id $SUBNET_ID --region $REGION > /dev/null 2>&1
    echo "Deleted Subnet: $SUBNET_ID"
done

# Delete Key Pair
if aws ec2 describe-key-pairs --key-names "$KEY_NAME" --region $REGION &> /dev/null; then
    aws ec2 delete-key-pair --key-name "$KEY_NAME" --region $REGION > /dev/null 2>&1
    echo "Deleted Key Pair: $KEY_NAME"
else
    echo "Key Pair $KEY_NAME does not exist."
fi

# Delete Node Group
if [ -n "$NODE_GROUP_ARN" ]; then
    aws eks delete-nodegroup --cluster-name $EKS_CLUSTER_NAME --nodegroup-name $NODE_GROUP_NAME --region $REGION > /dev/null 2>&1
    echo "Deleted Node Group: $NODE_GROUP_NAME"
    # Wait for the node group to be deleted
    aws eks wait nodegroup-deleted --cluster-name $EKS_CLUSTER_NAME --nodegroup-name $NODE_GROUP_NAME --region $REGION > /dev/null 2>&1
    echo "Node Group $NODE_GROUP_NAME has been deleted."
else
    echo "Node Group $NODE_GROUP_NAME does not exist."
fi

# Delete EKS Cluster
if aws eks describe-cluster --name $EKS_CLUSTER_NAME --region $REGION &> /dev/null; then
    aws eks delete-cluster --name $EKS_CLUSTER_NAME --region $REGION > /dev/null 2>&1
    echo "Deleted EKS Cluster: $EKS_CLUSTER_NAME"
    # Wait for the EKS cluster to be deleted
    aws eks wait cluster-deleted --name $EKS_CLUSTER_NAME --region $REGION > /dev/null 2>&1
    echo "EKS Cluster $EKS_CLUSTER_NAME has been deleted."
else
    echo "EKS Cluster $EKS_CLUSTER_NAME does not exist."
fi

# Delete VPC
if [ -n "$VPC_ID" ]; then
    aws ec2 delete-vpc --vpc-id $VPC_ID --region $REGION > /dev/null 2>&1
    echo "Deleted VPC: $VPC_ID"
else
    echo "VPC $VPC_ID does not exist."
fi

echo "Cleanup completed successfully."

